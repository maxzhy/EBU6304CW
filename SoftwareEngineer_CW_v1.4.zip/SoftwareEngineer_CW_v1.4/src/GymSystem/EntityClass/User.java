package GymSystem.EntityClass;

public abstract class User {
    private String name;
    private boolean isMan;
    private String phone;
    private void signUp(){}
}
