package GymSystem.EntityClass;

public class GoldMemberAccount {
    private boolean isGold;
    private void getRecommendation(){}
}
