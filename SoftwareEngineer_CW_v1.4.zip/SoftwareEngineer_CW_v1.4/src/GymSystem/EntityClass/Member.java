package GymSystem.EntityClass;

public class Member extends User{
    private String hobby;
    private String intension;
    private void logIn(){}
}
