package GymSystem.EntityClass;

public class MemberAccount extends Account{
    private boolean isGeneral;
    private double balance;
    private void recharge(){}
    private void upgrade(){}
}
