package GymSystem.EntityClass;

public class PremierMemberAccount {
    private boolean isSilver;
    private void bookLiveSeesion(){}
}
