package GymSystem.EntityClass;

public class Trainer extends User{
    private int numOfStudent;
    private String field;
    private void logIn(){}
    private void makeLiveSession(){}
}
