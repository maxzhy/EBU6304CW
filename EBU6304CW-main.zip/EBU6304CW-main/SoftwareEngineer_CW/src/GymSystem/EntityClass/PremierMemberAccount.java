package GymSystem.EntityClass;

/**
 * class for premier member account
 * <p>class for premier member account</p>
 * @author Yongfan Jin
 * @since 1.0
 * @version 1.0
 */
public class PremierMemberAccount {
    private boolean isSilver;
    private void bookLiveSeesion(){}
}
