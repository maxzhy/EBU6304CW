package GymSystem.EntityClass;

/**
 * class for member
 * <p>class for member</p>
 * @author Yongfan Jin
 * @since 1.0
 * @version 1.0
 */
public class Member extends User{
    private String hobby;
    private String intension;
    private void logIn(){}
}
