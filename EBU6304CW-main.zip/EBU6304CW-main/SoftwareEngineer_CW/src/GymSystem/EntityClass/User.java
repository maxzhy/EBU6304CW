package GymSystem.EntityClass;

/**
 * class for user
 * <p>class for user</p>
 * @author Yongfan Jin
 * @since 1.0
 * @version 1.0
 */
public abstract class User {
    private String name;
    private boolean isMan;
    private String phone;
    private void signUp(){}
}
