package GymSystem.EntityClass;

/**
 * class for trainer
 * <p>class for trainer</p>
 * @author Yongfan Jin
 * @since 1.0
 * @version 1.0
 */
public class Trainer extends User{
    private int numOfStudent;
    private String field;
    private void logIn(){}
    private void makeLiveSession(){}
}
