package GymSystem.BoundaryClass.Member;

import GymSystem.ControlClass.VideoSystem;
import GymSystem.ControlClass.VideoSystemCheck;
import GymSystem.ControlClass.GymSystem;
import GymSystem.ControlClass.GymSystemCheck;
import GymSystem.ControlClass.JumpTo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.image.ImageView;

import java.io.IOException;
import java.util.ArrayList;

public class MemberWatchVideoController {
    @FXML
    public JumpTo jump = new JumpTo();
    public Label username;
    public Label home;

    public Label signOut;
    public ImageView toMemberMain;
    public ListView<String> videoList;
    ArrayList<String> originalVideo = new ArrayList<String>();

    public ObservableList<String> videoShow = FXCollections.observableArrayList();
    //public ObservableList<String> oneLine = FXCollections.observableArrayList();

    public void initialize() throws IOException{
        videoList.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        showVideos();
    }

    public void showVideos() throws IOException{
        videoList.getItems().clear();

        String type = GymSystemCheck.checkAccountInfo(GymSystemCheck.accountNumber,"type");
        /*switch (type) {
            case "member" : System.out.println("member"); break;
            case "premier" : break;
            case "platinum" : break;
            default : break;
        }*/
        originalVideo = VideoSystemCheck.checkVideos(type);
        videoList.getItems().clear();
        for (int i = 0; i<originalVideo.size();i++){
            videoShow.add(i+1 + ": "+originalVideo.get(i));
        }
        videoList.setItems(videoShow);
    }

    public void playVideo() {
        for (String s: videoList.getSelectionModel().getSelectedItems()) {
            String oneLine = s.split("/")[1];
            VideoSystem.openVideo(oneLine);
        }
    }

    public void toMemberMain() throws IOException{
        jump.toMemberMain(signOut.getScene());
    }
    public void toMemberLive() throws IOException{
        jump.toMemberLive(signOut.getScene());
    }

    public void signOut()throws IOException {
        GymSystemCheck.setAccountNumber(null);
        GymSystemCheck.setLogInState("not");
        jump.toMain(signOut.getScene());
    }
}
