package GymSystem.BoundaryClass.Trainer;

import GymSystem.ControlClass.GymSystemCheck;
import GymSystem.ControlClass.JumpTo;
import GymSystem.ControlClass.VideoSystem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.File;
import java.io.IOException;


//Ma Zhaoyang
public class TrainerUploadVideoController {
    public TextField title, comment;
    public Button videoUploadButton, pathChooseButton;
    public Label pathBoard;
    public RadioButton general;
    public RadioButton platinum;
    public boolean isGeneral;
    public boolean isPlatinum;



    @FXML
    /*public void initialize()throws IOException{
        username.setText(GymSystemCheck.checkAccountInfo(GymSystemCheck.accountNumber,"username"));
    }*/
    public JumpTo jump = new JumpTo();
    public Label username;
    public Label signOut;
    public ImageView backToTrainerMain;

    public File path;

    public void setTypeGeneral() {
        if (isGeneral) {
            general.setSelected(true);
            return;
        }
        if (isPlatinum) {
            general.setSelected(!isGeneral);
            platinum.setSelected(!isPlatinum);
        }
        isGeneral = general.isSelected();
        isPlatinum = platinum.isSelected();
    }

    public void setTypePlatinum() {
        if (isPlatinum) {
            platinum.setSelected(true);
            return;
        }
        if (isGeneral) {
            general.setSelected(!isGeneral);
            platinum.setSelected(!isPlatinum);
        }
        isGeneral = general.isSelected();
        isPlatinum = platinum.isSelected();
    }

    //寻找视频路径
    public void videoPathDefine() throws IOException{
        path = VideoSystem.videoPathChoose();
        pathBoard.setText(path.toString());
    }

    //上传video并在txt中记录
    public void videoUpload() throws IOException {
        boolean typeLegal = isGeneral || isPlatinum;
        if (!typeLegal) {
            pathBoard.setText("Please choose video type!");
            return;
        }

        String titleInput = title.getText();
        String commentInput = comment.getText();
        String typeInput = isGeneral ? "general" : "platinum";
        String trainerInput;

        title.setText("");
        comment.setText("");
        pathBoard.setText(path.toString()+ " Upload Successfully!");

        trainerInput = GymSystemCheck.checkAccountInfo(GymSystemCheck.accountNumber,"username");

        //添加视频信息
        int currentVideo = VideoSystem.addVideoInfo(titleInput, commentInput, typeInput, trainerInput);

        //视频复制
        FileInputStream in = new FileInputStream(path);
        FileOutputStream out = new FileOutputStream("src/GymSystem/videos/"+Integer.toString(currentVideo)+".mp4");
        byte[] bytes = new byte[1024];
        int len;
        while ((len = in.read(bytes)) != -1) {
            out.write(bytes, 0, len);
        }
        in.close();
        out.close();
    }

    //退出登录
    public void signOut()throws IOException {
        GymSystemCheck.setAccountNumber(null);
        GymSystemCheck.setLogInState("not");
        jump.toMain(signOut.getScene());
    }
    public void toTrainerMain() throws IOException{
        jump.toTrainerMain(signOut.getScene());
    }
}
