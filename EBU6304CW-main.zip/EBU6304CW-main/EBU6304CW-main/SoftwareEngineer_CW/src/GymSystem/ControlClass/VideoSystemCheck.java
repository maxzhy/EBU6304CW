package GymSystem.ControlClass;

import GymSystem.EntityClass.Account;
import GymSystem.EntityClass.Income;
import GymSystem.EntityClass.NumberOfAccount;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;


public class VideoSystemCheck {
    public static ArrayList<String> checkVideos(String type) throws IOException{
        String fileName = "src/GymSystem/videos/videoinfo.txt";
        FileReader fileReader = new FileReader(fileName);
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String oneLine;
        String videoType;
        ArrayList<String> videos = new ArrayList<String>();

        if (type.equals("admin") || type.equals("trainer") || type.equals("platinum")) {
            while ((oneLine = bufferedReader.readLine()) != null) {
                videos.add(oneLine.split("/")[4]+ " - " +oneLine.split("/")[1]+ " - " +oneLine.split("/")[2]+ " /" +oneLine.split("/")[0]);
            }
        } else if(type.equals("member") || type.equals("premier")) {
            while ((oneLine = bufferedReader.readLine()) != null) {
                if (oneLine.split("/")[3].equals("general")) {
                    videos.add(oneLine.split("/")[4]+ " - " +oneLine.split("/")[1]+ " - " +oneLine.split("/")[2]+ " /" +oneLine.split("/")[0]);
                }
            }
        }

        return videos;
    }
}
