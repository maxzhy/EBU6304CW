package GymSystem.ControlClass;

import javafx.stage.FileChooser;
import javafx.stage.Window;

import java.io.*;
import java.util.Scanner;

public interface VideoSystem {

    static int addVideoInfo(String title, String comment, String type, String trainer) throws IOException{
        String fileName = "src/GymSystem/videos/videoinfo.txt";

        int count = 1;
        File file = new File(fileName);
        FileInputStream fis = new FileInputStream(file);
        Scanner scanner = new Scanner(fis);
        while(scanner.hasNextLine()){
            scanner.nextLine();
            count++;
        }
        String lines = Integer.toString(count);

        FileWriter fileWriter = new FileWriter(fileName, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        String accountInfo = lines + '/' + title + '/' + comment+ '/' +type+ '/' +trainer;
        bufferedWriter.write(accountInfo);
        bufferedWriter.newLine();
        bufferedWriter.flush();
        bufferedWriter.close();
        fileWriter.close();

        return count;
    }

    //4.24Ma Zhaoyang 弹窗找video
    static File videoPathChoose() throws IOException {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Video Files", "*.mp4", "*.mov")
        );

        Window primaryStage = null;
        File selectedFile = fileChooser.showOpenDialog(primaryStage);
        if (selectedFile != null) {
            return (selectedFile);
        }
        return null;
    }

    static void openVideo(String num) {
        Runtime rn = Runtime.getRuntime();
        Process p = null;
        File file = new File("src/GymSystem/videos" +num+ ".mp4");
        try {
            if(System.getProperty("os.name").equals("Mac OS X")){
                p = rn.exec( "open " + "src/GymSystem/videos/"+num+".mp4");
            }else{
                Runtime.getRuntime().exec("C:/Windows/System32/cmd.exe /k start "+file);
            }
            InputStream in = p.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String str = null;
            while((str=br.readLine()) != null){
                System.out.println(str);
            }
            br.close();
        }catch(Exception e) {
            System.out.println( "Error exec notepad!");
        }
    }
}
